<?php include 'header.php'; ?>

<div class="section textcenter errorpage">
    <h1>Error 404</h1>
    <p>Page not found..</p>
</div></div>

<?php include 'footer.php'; ?>